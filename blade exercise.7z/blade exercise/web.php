<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EBAController;

Route::get('/master', [EBAController::class, 'master']);
Route::get('/about', [EBAController::class, 'about']);
Route::get('/list', [EBAController::class, 'list']);