<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EBAController extends Controller
{
    
public function master(){
        return view('subview.master');
    }
public function list(){
        return view('subview.list');
    }
public function about(){
        return view('subview.about');
    }
}
