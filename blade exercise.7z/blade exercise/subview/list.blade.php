<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    </h2>Here are the list</h2>
    <ul>
  <li>harry potter</li>
  <li>Tea story</li>
  <li>Godzilla</li>
  <li>Coding is fun</li>
  <li>Lifestyle hacks/li>
  <li>Meow cat</li>
</ul> 
</body>
</html>